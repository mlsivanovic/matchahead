# 05. Pravi rasporedi i pouzdano osvežavanje

## Prompt za Grok

Pročitaj `00-stalni-kontekst.md`, `docs/progress.md` ako postoji i ovaj zadatak. Izvedi samo ovu celinu. Glavni plan koristi kao referencu za relevantne detalje, ne kao nalog da napraviš sve odjednom.

**Preduslovi:** 01 i 03; ne zavisi od završenog push-a.

## Posao

Implementiraj potvrđene adaptere izvora, normalizaciju i statički JSON koji koristi PWA. Dodaj GitHub Actions za osvežavanje zajedničkih podataka, početno na tri sata i ručno, u okviru izmerene kvote.

Trajno čuvaj prethodno validirano stanje i revizije u dozvoljenom formatu. Razlikuj pokušaj preuzimanja, uspešnu proveru izvora i stvarnu promenu sadržaja. Ne inkrementiraj reviziju događaja pri identičnom odgovoru.

Validiraj kompletan odgovor i paginaciju pre objave. Timeout, 429 ili nepotpun/prazan odgovor ne smeju obrisati prethodni raspored. Eksplicitne statuse odlaganja i otkazivanja mapirati odvojeno.

Sačuvaj interni fixture ID pri promeni vremena i naziva kluba. Kod promene provajdera koristi provereno mapiranje, a ne naivno poređenje imena i datuma.

Objavljuj manifest svežine i kompaktan indeks promena koji će služiti budućem notification servisu. On sadrži sportske podatke, ne korisnike ili njihove uređaje.

Na stranici kluba poveži spisak takmičenja i kvalitet pokrivenosti. Sezonski prelazak ne sme promeniti identitet kluba ili stabilnu putanju njegovih podataka.

## Uslov završetka

Aplikacija prikazuje proverene stvarne rasporede i njihove izvore. Testovi za pomeranje, otkazivanje, duplikate, paginaciju i pad provajdera prolaze. Dva uzastopna identična preuzimanja ne prave lažne promene. Objavljivanje podataka ne briše frontend.

## Predaja

Navedi izmenjene datoteke, konkretno demonstrirano ponašanje, komande i rezultate testova, neizvršene provere i preostale prepreke. Ažuriraj `docs/progress.md`. Ne označavaj ovu celinu DONE ako kriterijumi nisu ispunjeni.
